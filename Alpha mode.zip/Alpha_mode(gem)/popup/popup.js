document.addEventListener('DOMContentLoaded', () => {
    const toggleSwitch = document.getElementById('toggle-switch');
    const statusText = document.getElementById('status-text');
    const optionsBtn = document.getElementById('options-btn');

    // Load current state from storage
    chrome.storage.sync.get('isEnabled', (data) => {
        toggleSwitch.checked = data.isEnabled !== false; // default to true
        updateStatusText(toggleSwitch.checked);
    });

    // Handle toggle switch change
    toggleSwitch.addEventListener('change', () => {
        const isEnabled = toggleSwitch.checked;
        chrome.storage.sync.set({ isEnabled: isEnabled });
        updateStatusText(isEnabled);
    });

    // Handle options button click
    optionsBtn.addEventListener('click', () => {
        chrome.runtime.openOptionsPage();
    });

    function updateStatusText(isEnabled) {
        statusText.textContent = isEnabled ? 'Focus Mode is ON' : 'Focus Mode is OFF';
    }
});


