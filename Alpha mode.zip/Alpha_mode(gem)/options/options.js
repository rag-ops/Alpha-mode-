document.addEventListener('DOMContentLoaded', () => {
    // Site list elements
    const siteInput = document.getElementById('site-input');
    const addSiteBtn = document.getElementById('add-site-btn');
    const blockedSitesList = document.getElementById('blocked-sites-list');

    // Quote elements
    const quoteTypeRadios = document.querySelectorAll('input[name="quoteType"]');
    const customQuotesSection = document.getElementById('custom-quotes-section');
    const quoteInput = document.getElementById('quote-input');
    const addQuoteBtn = document.getElementById('add-quote-btn');
    const customQuotesList = document.getElementById('custom-quotes-list');

    // --- INITIAL LOAD ---
    loadSettings();

    // --- EVENT LISTENERS ---
    addSiteBtn.addEventListener('click', addSite);
    siteInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addSite();
    });

    addQuoteBtn.addEventListener('click', addQuote);
    quoteInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addQuote();
    });
    
    blockedSitesList.addEventListener('click', handleListClick);
    customQuotesList.addEventListener('click', handleListClick);

    quoteTypeRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            const quoteType = e.target.value;
            chrome.storage.sync.set({ quoteType: quoteType });
            toggleCustomQuotesView(quoteType);
        });
    });

    // --- FUNCTIONS ---
    function loadSettings() {
        chrome.storage.sync.get(['blockedSites', 'customQuotes', 'quoteType'], (data) => {
            renderList(data.blockedSites || [], blockedSitesList, 'site');
            renderList(data.customQuotes || [], customQuotesList, 'quote');
            
            const quoteType = data.quoteType || 'generated';
            document.querySelector(`input[name="quoteType"][value="${quoteType}"]`).checked = true;
            toggleCustomQuotesView(quoteType);
        });
    }

    function renderList(items, listElement, type) {
        listElement.innerHTML = '';
        items.forEach(item => {
            const li = document.createElement('li');
            
            const textSpan = document.createElement('span');
            textSpan.textContent = item;
            
            const removeBtn = document.createElement('button');
            removeBtn.innerHTML = '&times;';
            removeBtn.className = 'remove-btn';
            removeBtn.dataset.item = item;
            removeBtn.dataset.type = type;

            li.appendChild(textSpan);
            li.appendChild(removeBtn);
            listElement.appendChild(li);
        });
    }

    function addSite() {
        let newSite = siteInput.value.trim().toLowerCase();
        if (newSite) {
            try {
                // Basic validation: remove protocols and get the hostname
                if (!/^https?:\/\//i.test(newSite)) {
                    newSite = 'http://' + newSite;
                }
                const hostname = new URL(newSite).hostname.replace('www.', '');
                
                chrome.storage.sync.get({blockedSites: []}, (data) => {
                    const sites = data.blockedSites;
                    if (!sites.includes(hostname)) {
                        sites.push(hostname);
                        chrome.storage.sync.set({ blockedSites: sites }, () => {
                            renderList(sites, blockedSitesList, 'site');
                            siteInput.value = '';
                        });
                    }
                });
            } catch (error) {
                console.error("Invalid URL format:", siteInput.value);
                siteInput.style.borderColor = 'red';
                setTimeout(() => { siteInput.style.borderColor = ''; }, 2000);
            }
        }
    }

    function addQuote() {
        const newQuote = quoteInput.value.trim();
        if (newQuote) {
            chrome.storage.sync.get({customQuotes: []}, (data) => {
                const quotes = data.customQuotes;
                 if (!quotes.includes(newQuote)) {
                    quotes.push(newQuote);
                    chrome.storage.sync.set({ customQuotes: quotes }, () => {
                        renderList(quotes, customQuotesList, 'quote');
                        quoteInput.value = '';
                    });
                }
            });
        }
    }

    function handleListClick(e) {
        if (e.target.classList.contains('remove-btn')) {
            const itemToRemove = e.target.dataset.item;
            const type = e.target.dataset.type;

            if (type === 'site') {
                chrome.storage.sync.get('blockedSites', (data) => {
                    const sites = data.blockedSites.filter(site => site !== itemToRemove);
                    chrome.storage.sync.set({ blockedSites: sites }, () => {
                        renderList(sites, blockedSitesList, 'site');
                    });
                });
            } else if (type === 'quote') {
                chrome.storage.sync.get('customQuotes', (data) => {
                    const quotes = data.customQuotes.filter(quote => quote !== itemToRemove);
                    chrome.storage.sync.set({ customQuotes: quotes }, () => {
                        renderList(quotes, customQuotesList, 'quote');
                    });
                });
            }
        }
    }

    function toggleCustomQuotesView(quoteType) {
        if (quoteType === 'custom') {
            customQuotesSection.style.display = 'block';
        } else {
            customQuotesSection.style.display = 'none';
        }
    }
});


