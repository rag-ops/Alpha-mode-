// background.js - Handles the core blocking logic

// 1. Set default values on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    isEnabled: true,
    blockedSites: ['youtube.com', 'facebook.com', 'instagram.com', 'twitter.com', 'tiktok.com', 'reddit.com'],
    quoteType: 'generated',
    customQuotes: ['Your focus determines your reality.']
  });
});

// 2. Listen for navigation events
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  // Ignore sub-frame navigations
  if (details.frameId !== 0) {
    return;
  }

  chrome.storage.sync.get(['isEnabled', 'blockedSites'], (data) => {
    if (data.isEnabled && data.blockedSites) {
      const url = new URL(details.url);
      const hostname = url.hostname.replace('www.', '');

      // Check if the current site is in the block list
      if (data.blockedSites.some(site => hostname.includes(site))) {
        // Redirect to the blocked page
        const blockedPageUrl = chrome.runtime.getURL('blocked/blocked.html');
         chrome.tabs.update(details.tabId, { url: blockedPageUrl });
      }
    }
  });
}, { url: [{ urlMatches: 'https?://*/*' }] });


