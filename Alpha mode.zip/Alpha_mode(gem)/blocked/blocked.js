document.addEventListener('DOMContentLoaded', () => {
    const quoteWrapper = document.querySelector('.quote-wrapper');
    const quoteTextElement = document.getElementById('quote-text');
    const authorTextElement = document.getElementById('author-text');

    // Pre-selected "AI-Generated" quotes
    const generatedQuotes = [
        { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
        { text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
        { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
        { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
        { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson" },
        { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
        { text: "Discipline is the bridge between goals and accomplishment.", author: "Jim Rohn" },
        { text: "Focus on being productive instead of busy.", author: "Tim Ferriss"}
    ];

    function displayQuote(quote) {
        if (typeof quote === 'object' && quote.text) {
            quoteTextElement.textContent = quote.text;
            authorTextElement.textContent = `— ${quote.author}`;
        } else {
            quoteTextElement.textContent = quote;
            authorTextElement.textContent = '— Your own wisdom';
        }
        // Trigger the fade-in animation
        quoteWrapper.style.opacity = 1;
        quoteWrapper.style.transform = 'translateY(0)';
    }

    chrome.storage.sync.get(['quoteType', 'customQuotes'], (data) => {
        let selectedQuote;
        const useCustom = data.quoteType === 'custom' && data.customQuotes && data.customQuotes.length > 0;
        
        if (useCustom) {
            // Pick a random custom quote
            selectedQuote = data.customQuotes[Math.floor(Math.random() * data.customQuotes.length)];
        } else {
            // Pick a random generated quote
            selectedQuote = generatedQuotes[Math.floor(Math.random() * generatedQuotes.length)];
        }
        
        // A small delay to ensure the DOM is ready before animating
        setTimeout(() => displayQuote(selectedQuote), 50);
    });
});


